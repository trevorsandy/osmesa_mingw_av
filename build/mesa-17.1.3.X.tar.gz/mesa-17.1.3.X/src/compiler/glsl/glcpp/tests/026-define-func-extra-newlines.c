#define foo(a) bar

foo
(
1
)
