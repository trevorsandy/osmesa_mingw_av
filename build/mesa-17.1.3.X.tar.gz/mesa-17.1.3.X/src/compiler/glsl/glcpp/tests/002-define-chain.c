#define foo 1
#define bar foo
bar
