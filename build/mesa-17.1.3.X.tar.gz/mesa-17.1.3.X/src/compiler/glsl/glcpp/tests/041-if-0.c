success_1
#if 0
failure
#endif
success_2
