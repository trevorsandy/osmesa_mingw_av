#if(1)
success
#endif
