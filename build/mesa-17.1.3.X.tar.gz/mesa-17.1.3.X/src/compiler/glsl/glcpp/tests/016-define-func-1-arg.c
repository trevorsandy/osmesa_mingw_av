#define foo(x) ((x)+1)
foo(bar)
