#define bar a foo
#define foo 1
bar
