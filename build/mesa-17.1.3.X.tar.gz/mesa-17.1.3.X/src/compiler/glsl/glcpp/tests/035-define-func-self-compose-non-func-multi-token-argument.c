#define foo(bar) bar
foo(1+foo)
