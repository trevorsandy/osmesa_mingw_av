#define expand(x) expand(x once)
#define foo(x) x
foo(expand(just))
