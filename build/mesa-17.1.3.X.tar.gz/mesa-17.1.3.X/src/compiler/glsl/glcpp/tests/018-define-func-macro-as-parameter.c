#define x 0
#define foo(x) x
foo(1)
