#define foo(bar) bar
foo bar
