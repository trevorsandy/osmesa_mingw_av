#define foo(x,y) x,two fish,red fish,y
foo(one fish, blue fish)
