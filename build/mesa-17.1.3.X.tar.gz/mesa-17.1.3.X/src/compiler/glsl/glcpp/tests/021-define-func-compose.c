#define bar(x) (1+(x))
#define foo(y) (2*(y))
foo(bar(3))
