#define foo 1
foo
#undef foo
foo
#define foo 2
foo
