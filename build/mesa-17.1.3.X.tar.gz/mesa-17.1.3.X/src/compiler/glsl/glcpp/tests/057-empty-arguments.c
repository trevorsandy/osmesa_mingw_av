#define zero() success
zero()
#define one(x) success
one()
#define two(x,y) success
two(,)
