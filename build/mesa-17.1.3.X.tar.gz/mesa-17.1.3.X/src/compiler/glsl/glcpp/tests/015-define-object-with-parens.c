#define foo ()1
foo()
#define bar ()2
bar()
