#define  foo foo
#define  bar foo
bar
