#define foo(a,b)
#if 0
foo(bar)
foo(
#endif
