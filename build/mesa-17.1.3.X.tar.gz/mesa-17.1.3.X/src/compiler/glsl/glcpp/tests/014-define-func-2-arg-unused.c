#define foo(x,y) 1
foo(bar,baz)
