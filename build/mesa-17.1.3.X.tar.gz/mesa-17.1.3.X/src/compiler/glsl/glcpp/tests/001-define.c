#define foo 1
foo
