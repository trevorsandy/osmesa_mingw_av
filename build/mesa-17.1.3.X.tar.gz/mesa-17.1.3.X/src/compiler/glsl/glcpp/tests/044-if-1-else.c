success_1
#if 1
success_2
#else
failure
#endif
success_3
