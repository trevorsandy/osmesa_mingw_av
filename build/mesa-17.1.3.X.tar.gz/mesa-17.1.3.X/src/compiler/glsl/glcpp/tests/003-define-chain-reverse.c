#define bar foo
#define foo 1
bar
