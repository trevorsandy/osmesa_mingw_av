#if 1 + 2 * 3 + - (25 % 17 - + 1)
failure with operator precedence
#else
success
#endif
