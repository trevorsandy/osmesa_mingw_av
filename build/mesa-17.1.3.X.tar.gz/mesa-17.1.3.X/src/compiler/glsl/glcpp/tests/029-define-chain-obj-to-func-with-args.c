#define bar(failure) failure
#define foo bar(success)
foo
