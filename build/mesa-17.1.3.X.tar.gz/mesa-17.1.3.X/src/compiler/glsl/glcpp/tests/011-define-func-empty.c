#define foo()
foo()
