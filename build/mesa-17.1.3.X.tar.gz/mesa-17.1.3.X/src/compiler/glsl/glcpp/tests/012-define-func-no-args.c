#define foo() bar
foo()
