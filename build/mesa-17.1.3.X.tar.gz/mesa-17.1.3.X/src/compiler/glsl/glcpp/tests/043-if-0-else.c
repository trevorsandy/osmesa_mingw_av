success_1
#if 0
failure
#else
success_2
#endif
success_3
