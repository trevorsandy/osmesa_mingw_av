#define paste(a,b) a ## b
paste(one , token)
