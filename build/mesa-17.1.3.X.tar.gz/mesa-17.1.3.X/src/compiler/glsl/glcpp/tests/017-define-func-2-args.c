#define foo(x,y) ((x)*(y))
foo(bar,baz)
