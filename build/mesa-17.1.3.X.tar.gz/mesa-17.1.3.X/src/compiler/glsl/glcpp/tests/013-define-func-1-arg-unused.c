#define foo(x) 1
foo(bar)
