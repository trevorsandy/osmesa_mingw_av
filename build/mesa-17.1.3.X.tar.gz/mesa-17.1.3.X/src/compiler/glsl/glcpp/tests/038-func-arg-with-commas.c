#define foo(x) success
foo(argument (with,embedded , commas) -- tricky)
