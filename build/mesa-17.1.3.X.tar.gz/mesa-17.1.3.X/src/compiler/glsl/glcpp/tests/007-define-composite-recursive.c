#define foo a bar
#define bar b baz
#define baz c foo
foo
bar
baz
