#define double(a) a*2
#define foo double(
foo 5)
