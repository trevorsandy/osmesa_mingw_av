#define success() failure
#define foo success
foo
