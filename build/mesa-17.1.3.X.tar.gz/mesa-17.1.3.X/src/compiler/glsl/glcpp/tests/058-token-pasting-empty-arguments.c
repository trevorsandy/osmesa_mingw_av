#define paste(x,y) x ## y
paste(a,b)
paste(a,)
paste(,b)
paste(,)
