success_1
#if 0
failure_1
#if 1
failure_2
#else
failure_3
#endif
failure_4
#endif
success_2
