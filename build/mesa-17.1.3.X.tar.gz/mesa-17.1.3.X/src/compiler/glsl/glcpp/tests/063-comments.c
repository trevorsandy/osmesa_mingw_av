/* this is a comment */
// so is this
// */
f = g/**//h;
/*//*/l();
m = n//**/o
+ p;
/* this
comment spans
multiple lines and
contains *** stars
and slashes / *** /
and other stuff.
****/
more code here
/* Test that /* nested
   comments */
are not treated like comments.
/*/ this is a comment */
/*/*/
