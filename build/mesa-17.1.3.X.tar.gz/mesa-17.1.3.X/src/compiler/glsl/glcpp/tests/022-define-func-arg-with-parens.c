#define foo(x) (x)
foo(argument(including parens)for the win)
