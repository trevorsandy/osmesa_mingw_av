#define failure() success
#define foo failure()
foo
