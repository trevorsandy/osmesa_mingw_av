#define paste(x,y) x ## y
paste(1,2)
paste(1,000)
paste(identifier,2)
