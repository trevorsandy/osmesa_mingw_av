#define bar success
#define foo(x) x
foo(more bar)
