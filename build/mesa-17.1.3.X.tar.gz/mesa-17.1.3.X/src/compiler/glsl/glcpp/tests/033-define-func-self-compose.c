#define foo(a) foo(2*(a))
foo(foo(3))
