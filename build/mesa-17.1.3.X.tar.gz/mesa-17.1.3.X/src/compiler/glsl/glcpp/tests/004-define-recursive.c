#define foo bar
#define bar baz
#define baz foo
foo
bar
baz
