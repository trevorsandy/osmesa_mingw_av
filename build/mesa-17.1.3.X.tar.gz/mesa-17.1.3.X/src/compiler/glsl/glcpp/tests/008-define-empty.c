#define foo
foo
