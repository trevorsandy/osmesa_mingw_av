#define foo(x) (x)
foo(this is more than one word)
