#define foo 1
foo
#undef foo
foo
