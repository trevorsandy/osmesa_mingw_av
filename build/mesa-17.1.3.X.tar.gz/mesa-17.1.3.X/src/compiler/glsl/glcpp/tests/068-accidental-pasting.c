#define empty
<empty<
<empty=
>empty>
>empty=
=empty=
!empty=
&empty&
|empty|
+empty+
-empty-
