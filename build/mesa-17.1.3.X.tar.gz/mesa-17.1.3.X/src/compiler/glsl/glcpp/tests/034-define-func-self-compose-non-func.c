#define foo(bar) bar
foo(foo)
